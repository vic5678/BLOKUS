
#include "board.h"
#include "player.h"

// TODO: Implement here the method pieceCanBePlaced and computeScore of Board
// Do not implement any other methods of Board (as they are already implemented in file board.cpp)

bool Board::pieceCanBePlaced(Piece* piece, int x, int y) {

int i,j;
   //checks if the piece is inside the bounds of the board
         if(x<0|| x+piece->getSizeX()>14 || y+piece->getSizeY()>14 ||y<0)
                return false;
    char player;
	player=piece->getPlayer();

   // first movement
   if(playerHasPlacedNoPieces(player)){
		if(player == '#'){
                	for(i=0; i<piece->getSizeX(); i++){
	 for(j=0; j<piece->getSizeY(); j++){
	 if(x+i==4 && y+j==4)
	    return true;
            else
                return false;}}}

		else if(player == 'O'){
           for(i=0; i<piece->getSizeX(); i++){
	 for(j=0; j<piece->getSizeY(); j++){
	 if(x+i==9 && y+j==9)
                return true;

            else
                return false;}}
		}}



	//checks if the piece falls on top of any other piece

	for(i=0; i<piece->getSizeX(); i++){
	 for(j=0; j<piece->getSizeY(); j++){
	 if(hasPiece(x+i,y+j)== true && piece->squareHasPiece(i,j)==true)
	return false;
}}

   //checks if the piece touches any other piece of the same player edge-by-edge.
   //checks if the piece touches at least one corner with any other piece of the same player.


 int k,l;
 for(k=0; k<piece->getSizeX(); k++)
 {
    for(l=0; l<piece->getSizeY(); l++)
    {
            if(piece->squareHasPiece(k,l))
        {

 	if(squareBelongsToPlayer(x+k,y-1,player) || squareBelongsToPlayer(x+k,y+piece->getSizeY(),player))
 	  return false;
 	if(squareBelongsToPlayer(x-1,y+l,player) || squareBelongsToPlayer(x+piece->getSizeX(),y+l,player))
 	  return false;


  if(squareBelongsToPlayer(x-1,y-1,player) || squareBelongsToPlayer(x+piece->getSizeX(),y-1,player))
		return true;
    else if(squareBelongsToPlayer(x-1,y+piece->getSizeY(),player) || squareBelongsToPlayer(x+piece->getSizeX(),y+piece->getSizeY(),player))
		return true;
     }
   }
}
return false;
}



int Board::computeScore(Player* player)
{
    int point, sum;
    point=0;
    sum =  player->getNumberOfPlacedPieces();
    char pl;
    pl=player->getSymbol();
    for(int j=0; j<14; j++){
       for(int k=0; k<14; k++){
      if(squareBelongsToPlayer(j,k,pl))
            point++;
    }}

    if (sum==21)
        point = point + 15;

   if(sum==21 ){
   	Piece* p2;
   	p2=getLastPiecePlayedByPlayer(player);
   	if(p2->getSizeX()==1 && p2->getSizeY()==1)
    point+=5;
   }

    return point;
}

