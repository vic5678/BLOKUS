#include <iostream>
#include <cstdlib>
#include "player.h"

// TODO: Implement here the methods of Player and all derived classes

Player::Player(int id){
	this->id=id;
    if(id==0){
        name="player 1";
        symbol= '#';}
    else if(id==1){
        name="player 2";
        symbol= 'O';
    }

   	numPieces=21;

	pieces= new Piece*[numPieces];//dynamikh desmeysh mnhmhs gia to piece
	createPieces();
}

Player::~Player(){
    int i;
	for(i=0; i<numPieces; i++)
	   delete pieces[i];
    delete []pieces;
}

int Player::getId(){
	return id;
}

char Player::getSymbol()
{
  if(id==0)
  return '#';
  else if(id==1)
  return 'O';
}

string Player::getName(){
	return name;
}


Piece* Player::getPiece(int index){
return pieces[index];
}

int Player::getNumberOfPlacedPieces(){
	int sum;
	sum=0;
	for(int i=0; i<21; i++)	{
	   if(pieces[i]->isPlaced())
	   sum++;
}
return sum;
  }

int Player::getNumberOfAvailablePieces(){
		int sum,avpieces;
	sum=0;
	for(int i=0; i<21; i++)	{
	   if(pieces[i]->isPlaced())
	   sum++;
}
avpieces=21-sum;
return avpieces;
}

HumanPlayer:: HumanPlayer(int id) : Player(id)
{
}

HumanPlayer:: HumanPlayer(int id, string name) : Player(id)
{

    this->name=name;
}

int ComputerPlayer::getRandomPieceId()
{
    return rand()%21+1;
}


ComputerPlayer:: ComputerPlayer(int id) : Player(id)
{

}
Orientation ComputerPlayer::getRandomOrientation(){

Orientation orientation = Orientation(rand()%4);
return orientation;
}

Flip ComputerPlayer:: getRandomFlip(){
Flip flip=Flip(rand()%2);
return flip;

}

